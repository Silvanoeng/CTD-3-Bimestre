public interface IRegistro {
    public void vacinar(Object[] informacoes);
}
