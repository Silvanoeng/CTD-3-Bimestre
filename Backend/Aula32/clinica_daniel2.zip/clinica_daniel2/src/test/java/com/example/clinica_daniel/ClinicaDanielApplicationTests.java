package com.example.clinica_daniel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaDanielApplicationTests {

	@Test
	void contextLoads() {
	}

}
