package com.example.clinica_daniel.repository;

import com.example.clinica_daniel.entity.EnderecoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EnderecoRepository extends JpaRepository<EnderecoEntity, Integer> {
}
