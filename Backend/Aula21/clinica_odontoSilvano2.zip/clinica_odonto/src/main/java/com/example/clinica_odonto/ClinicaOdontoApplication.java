package com.example.clinica_odonto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicaOdontoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClinicaOdontoApplication.class, args);
	}

}
