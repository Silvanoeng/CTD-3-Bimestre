package com.example.clinica_odonto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaOdontoApplicationTests {

	@Test
	void contextLoads() {
	}

}
